package com.incava.tp08todolist;

public class RecyclerItem {

    String name;

    public RecyclerItem(String name, String nick, String theme, String body) {
        this.name = name;
        this.nick = nick;
        this.theme = theme;
        this.body = body;
    }

    String nick;
    String theme;
    String body;



}
